Logo files, named by id from .site/_data/funders.json (png, jpg, svg or webp). A missing file falls back to the name as text.
eit-climate-kic.png was extracted from the Climate KIC partner brand guidelines (horizontal logo, page 15) with a transparent background.
fdc-messina.png is 300 px wide. It is sharp enough at the 36 to 44 px height used on the site. Swap in a larger original if the site ever shows it bigger.
blivande.png is the triangle mark supplied by the Lab. Confirm it is Blivande's.
